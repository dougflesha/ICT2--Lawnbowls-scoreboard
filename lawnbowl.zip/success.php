<!DOCTYPE html>
<html>
<head>
	<title>Welcome to LawnBowl</title>


<link rel="stylesheet" href="bsjs/bootstrap.min.css">
<script src="bsjs/jquery.min.js"></script>
<script src="bsjs/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/index.css">
</head>


<body style="background-color:rgb(33,150,243); overflow:hidden;">

<!-- LOGIN -->
<div class="jumbotron text-center" style="margin-left:auto;">
  <h1>Welcome to LawnBowl</h1> 
   <a type="submit" class="btn custom" style="margin-top:40px; color:white; text-decoration:none;" href="index.php">Get Started</a>

</div>
</body>
</html>
