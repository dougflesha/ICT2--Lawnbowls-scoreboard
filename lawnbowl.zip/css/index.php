<?php  

header('Location: ../');


?>