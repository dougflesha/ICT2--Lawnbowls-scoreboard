<?php
require 'friendhelper.php';
?>

<!DOCTYPE html>
<html>
<head>
	 
</head>
<body>
<p></p>
</body>
</html>
